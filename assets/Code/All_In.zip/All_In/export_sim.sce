// Export simulation data to CSV
// Columns : Time | X | Y | Theta | Lat_Err | F_Steer | R_Steer

Time    = Sim_X.time(:)         ;
X       = Sim_X.values(:)       ;
Y       = Sim_Y.values(:)       ;
Theta   = Sim_Theta.values(:)   ;
Lat_Err = Sim_Lat_Err.values(:) ;
F_Steer = Sim_F_Steer.values(:) ;
R_Steer = Sim_R_Steer.values(:) ;

N = min([length(Time), length(X), length(Y), length(Theta), length(Lat_Err), length(F_Steer), length(R_Steer)]) ;

csvWrite([Time(1:N), X(1:N), Y(1:N), Theta(1:N), Lat_Err(1:N), F_Steer(1:N), R_Steer(1:N)], 'sim_data.csv') ;

disp('Export OK : sim_data.csv -- ' + string(N) + ' points') ;
